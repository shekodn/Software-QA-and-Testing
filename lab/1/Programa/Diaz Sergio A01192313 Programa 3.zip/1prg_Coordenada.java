//&p-Coordenada
import java.io.*;
import java.util.*;

public class Coordenada {

    private double dX;
    private double dY;

    /* Getters */
    
    /**
     * Gets X coordinate
     * @return [description]
     */
    public double getX(){
        return dX;
    }

    /**
     * Gets Y coordinate
     * @return [description]
     */
    public double getY(){
        return dY;
    }

    /* Setters */

    /**
     * Sets X coordinate
     * @param double dX [description]
     */
    public void setX(double dX){
        this.dX = dX;
    }

    /**
     * sets Y coordinate
     * @param double dY [description]
     */
    public void setY(double dY){
        this.dY = dY;
    }

}
